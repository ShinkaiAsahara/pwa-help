import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const Details = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [trailer, setTrailer] = useState(null);

  const fetchMovieDetails = async () => {
    const response = await axios.get(`https://api.themoviedb.org/3/movie/${id}`, {
      params: {
        api_key: '7fdc70fe1b634f51d83c64b3ae32be49'
      }
    });
    setMovie(response.data);
  };

  const fetchMovieTrailer = async () => {
    const response = await axios.get(`https://api.themoviedb.org/3/movie/${id}/videos`, {
      params: {
        api_key: '7fdc70fe1b634f51d83c64b3ae32be49'
      }
    });
    setTrailer(response.data.results[0]?.key);
  };

  useEffect(() => {
    fetchMovieDetails();
    fetchMovieTrailer();
  }, [id]);

  return (
    <div className="movie-details">
      {movie && (
        <>
           <img
              className="movie-poster"
              src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
              alt={`${movie.title} Poster`}
            />
          <h1>{movie.title}</h1>
          <div className="movie-info">
            <p>{movie.overview}</p>
            <div className="movie-year-genre">
              <span>{movie.release_date.split('-')[0]}</span>
              <span>{movie.genres?.map(genre => genre.name).join(', ')}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Details;