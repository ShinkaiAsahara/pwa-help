import React from 'react';
import { Link } from 'react-router-dom';
import './App.css'; 

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar__logo">
        <Link to="/">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/7/7a/Logonetflix.png"
            alt="Netflix Logo"
          />
        </Link>
      </div>
      <ul className="navbar__links">
       
      </ul>
    </nav>
  );
};

export default Navbar;