import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import MovieCard from './MovieCard';

const API_KEY = '7fdc70fe1b634f51d83c64b3ae32be49';
const API_URL = 'https://api.themoviedb.org/3/discover/movie';

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sorting, setSorting] = useState('popularity.desc');
  const navigate = useNavigate();

  const fetchMovies = async (page = 1) => {
    setIsLoading(true);
    try {
      const response = await axios.get(API_URL, {
        params: {
          api_key: API_KEY,
          page,
          sort_by: sorting,
        },
      });
      setMovies((prevMovies) => [...prevMovies, ...response.data.results]);
    } catch (error) {
      console.error('Error fetching movies:', error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchMovies(currentPage);
  }, [currentPage, sorting]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSortChange = (e) => {
    setSorting(e.target.value);
    setMovies([]);
    setCurrentPage(1); 
  };

  const filteredMovies = movies.filter((movie) =>
    movie.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const loadMoreMovies = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  return (
    <div className="home">
      <div className="home__search">
        <input
          type="text"
          placeholder="Search movies..."
          value={searchTerm}
          onChange={handleSearch}
          className="search-input"
        />
        <select onChange={handleSortChange} value={sorting} className="sort-dropdown">
          <option value="popularity.desc">Most Popular</option>
          <option value="release_date.desc">Newest</option>
          <option value="vote_average.desc">Top Rated</option>
          <option value="original_title.asc">Title (A-Z)</option>
        </select>
      </div>
      <div className="movie-grid">
        {filteredMovies.map((movie) => (
          <MovieCard
            key={movie.id}
            movie={movie}
            onClick={() => navigate(`/movie/${movie.id}`)}
          />
        ))}
      </div>
      <div className="load-more-container">
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          <button onClick={loadMoreMovies} className="load-more-button">
            Load More
          </button>
        )}
      </div>
    </div>
  );
};

export default Home;