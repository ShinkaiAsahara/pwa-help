import React from 'react';
import { Link } from 'react-router-dom';
import './App.css';

const MovieCard = ({ movie }) => {
  const imageUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500/${movie.poster_path}`
    : 'https://via.placeholder.com/500x750?text=No+Image';

  return (
    <Link to={`/movie/${movie.id}`} className="movie-card">
      <img src={imageUrl} alt={movie.title || 'Movie Title'} />
      <h3>{movie.title || 'Untitled'}</h3>
    </Link>
  );
};

export default MovieCard;