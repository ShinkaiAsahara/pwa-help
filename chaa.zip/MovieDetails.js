import React from 'react';
import './App.css';

const MovieDetail = ({ movie }) => {
  return (
    <div className="movie-details">
      <div className="movie-detail-container">
        
        <div className="trailer-thumbnail-container">
          <img
            src={movie.trailerThumbnailUrl} 
            alt={`${movie.title} Trailer Thumbnail`}
            className="trailer-thumbnail"
          />
        </div>

        
        <div className="info-container">
          <h1>{movie.title}</h1>

          <div className="tags">
            <span>{movie.year}</span>
            <span className="genre-tag">{movie.genre}</span>
          </div>

          <p>{movie.description}</p>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;