import React, { useState, useEffect } from "react";
import SearchBar from "../components/SearchBar";
import MovieCard from "../components/MovieCard";
import { fetchMovies } from "../api"; 

const HomePage = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getMovies = async () => {
      try {
        const isOnline = navigator.onLine;
        if (isOnline) {
          const fetchedMovies = await fetchMovies();
          setMovies(fetchedMovies);
          localStorage.setItem("cachedMovies", JSON.stringify(fetchedMovies));
        } else {
          const cachedMovies = JSON.parse(localStorage.getItem("cachedMovies")); 
          if (cachedMovies) {
            setMovies(cachedMovies);
          } else {
            console.error("No cached movies available.");
          }
        }
      } catch (error) {
        console.error("Error fetching movies:", error);
      } finally {
        setLoading(false);
      }
    };

    getMovies();
  }, []);

  const handleSearchResults = (results) => {
    setMovies(results);
    localStorage.setItem("cachedMovies", JSON.stringify(results)); 
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className="homepage">
      <h1>Cathy Movies</h1>
      <SearchBar onSearch={handleSearchResults} />
      {movies.length > 0 ? (
        <div className="movie-grid">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      ) : (
        <p>No movies available.</p>
      )}
    </div>
  );
};

export default HomePage;
